Here's a script that serves as a tutorial to FFT's called plot_FFT_tutorial.py. You need to put the script, spectrum_wwind.py, in the same folder that plot_FFT_tutorial.py is in. Then just run plot_FFT_tutorial from your Spyder terminal and read through the comments to see what is going on.

